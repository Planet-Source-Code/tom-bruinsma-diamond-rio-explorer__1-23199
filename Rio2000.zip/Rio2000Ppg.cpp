// Rio2000Ppg.cpp : Implementation of the CRio2000PropPage property page class.

#include "stdafx.h"
#include "Rio2000.h"
#include "Rio2000Ppg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CRio2000PropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CRio2000PropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CRio2000PropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CRio2000PropPage, "RIO2000.Rio2000PropPage.1",
	0xe735c786, 0xfa52, 0x11d3, 0xbd, 0xb1, 0, 0x8, 0xc7, 0xf4, 0x8e, 0xfd)


/////////////////////////////////////////////////////////////////////////////
// CRio2000PropPage::CRio2000PropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CRio2000PropPage

BOOL CRio2000PropPage::CRio2000PropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_RIO2000_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CRio2000PropPage::CRio2000PropPage - Constructor

CRio2000PropPage::CRio2000PropPage() :
	COlePropertyPage(IDD, IDS_RIO2000_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CRio2000PropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CRio2000PropPage::DoDataExchange - Moves data between page and properties

void CRio2000PropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CRio2000PropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CRio2000PropPage message handlers
