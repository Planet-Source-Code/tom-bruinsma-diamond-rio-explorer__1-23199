//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Rio2000.rc
//
#define IDS_RIO2000                     1
#define IDD_ABOUTBOX_RIO2000            1
#define IDB_RIO2000                     1
#define IDI_ABOUTDLL                    1
#define IDS_RIO2000_PPG                 2
#define IDS_RIO2000_PPG_CAPTION         200
#define IDD_PROPPAGE_RIO2000            200
#define IDB_RIO                         201

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
