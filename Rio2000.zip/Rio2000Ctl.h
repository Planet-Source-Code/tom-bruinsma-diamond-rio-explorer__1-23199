#if !defined(AFX_RIO2000CTL_H__E735C793_FA52_11D3_BDB1_0008C7F48EFD__INCLUDED_)
#define AFX_RIO2000CTL_H__E735C793_FA52_11D3_BDB1_0008C7F48EFD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

 


// Rio2000Ctl.h : Declaration of the CRio2000Ctrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CRio2000Ctrl : See Rio2000Ctl.cpp for implementation.

class CRio2000Ctrl : public COleControl
{
	DECLARE_DYNCREATE(CRio2000Ctrl)

// Constructor
public:
	CRio2000Ctrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRio2000Ctrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	virtual DWORD GetControlFlags();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CRio2000Ctrl();

	DECLARE_OLECREATE_EX(CRio2000Ctrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CRio2000Ctrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CRio2000Ctrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CRio2000Ctrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CRio2000Ctrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CRio2000Ctrl)
	afx_msg long GetBadBlocks();
	afx_msg BSTR GetDevicePort();
	afx_msg void SetDevicePort(LPCTSTR lpszNewValue);
	afx_msg short GetFileCount();
	afx_msg BOOL GetMarkBadBlocks();
	afx_msg void SetMarkBadBlocks(BOOL bNewValue);
	afx_msg long GetMemoryFree();
	afx_msg long GetMemoryTotal();
	afx_msg long GetMemoryUsed();
	afx_msg BOOL GetUseExternal();
	afx_msg void SetUseExternal(BOOL bNewValue);
	afx_msg BOOL ChangeOrder(LPCTSTR Order);
	afx_msg BOOL FileRemove(LPCTSTR FileName);
	afx_msg BOOL FileRetrieve(LPCTSTR FileName);
	afx_msg BOOL FileSend(LPCTSTR FileName);
	afx_msg BOOL FilesRemoveAll();
	afx_msg BOOL GetDirectory();
	afx_msg BOOL GetHeader();
	afx_msg BOOL RioInitialize();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CRio2000Ctrl)
	void FireDirectoryEntry(short intFileNum, long lngFileSize, long lngBitRate, long lngSampleFreq, LPCTSTR strTime, LPCTSTR strFileName)
		{FireEvent(eventidDirectoryEntry,EVENT_PARAM(VTS_I2  VTS_I4  VTS_I4  VTS_I4  VTS_BSTR  VTS_BSTR), intFileNum, lngFileSize, lngBitRate, lngSampleFreq, strTime, strFileName);}
	void FireReturnError(LPCTSTR strError)
		{FireEvent(eventidReturnError,EVENT_PARAM(VTS_BSTR), strError);}
	void FireRioStatus(LPCTSTR strStatus)
		{FireEvent(eventidRioStatus,EVENT_PARAM(VTS_BSTR), strStatus);}
	void FireTransferProgress(short Position, short Total)
		{FireEvent(eventidTransferProgress,EVENT_PARAM(VTS_I2  VTS_I2), Position, Total);}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

		// directory block
	CDirBlock m_cDirBlock;

	// error str
	char m_szError[ 128 ];

	// external flash 32K block count
	UINT m_uiCount32KBlockAvailableExternal;

	// io port delay's
	long m_lTimeIODelayInit;
	long m_lTimeIODelayTx;
	long m_lTimeIODelayRx;

	// port constants
	int m_iPortBase;
	int m_iPortData;
	int m_iPortStatus;
	int m_iPortControl;

	// error
	int m_iIDError;

	// internal/external flash ram flag
	BOOL m_bUseExternalFlash;

	// special edition flag
	BOOL m_bSpecialEdition;

	// operations
	void LogError( int iType, const char* pszFormat, ... );
	UINT FindFirstFree32KBlock( void );
	UINT CalculateChecksum1( void );
	UINT CalculateChecksum2( void );
	BOOL WaitInput( int iValue );
	BOOL WaitAck( void );
	UINT GetDataByte( void );
	BOOL IOIntro( void );
	BOOL IOOutro( void );

	BOOL Tx32KBlockRetry( void* pv, UINT uiPos32KBlock, UINT uiPos32KBlockPrev,
		UINT uiPos32KBlockNext );
	BOOL Tx32KBlock( void* pv, UINT uiPos32KBlock, UINT uiPos32KBlockPrev,
		UINT uiPos32KBlockNext );
	BOOL Rx32KBlockRetry( void* pv, UINT uiPos32KBlock );
	BOOL Rx32KBlock( void* pv, UINT uiPos32KBlock );
	BOOL MarkBadBlocks();
// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CRio2000Ctrl)
	dispidBadBlocks = 1L,
	dispidDevicePort = 2L,
	dispidFileCount = 3L,
	dispidMarkBadBlocks = 4L,
	dispidMemoryFree = 5L,
	dispidMemoryTotal = 6L,
	dispidMemoryUsed = 7L,
	dispidUseExternal = 8L,
	dispidChangeOrder = 9L,
	dispidFileRemove = 10L,
	dispidFileRetrieve = 11L,
	dispidFileSend = 12L,
	dispidFilesRemoveAll = 13L,
	dispidGetDirectory = 14L,
	dispidGetHeader = 15L,
	dispidRioInitialize = 16L,
	eventidDirectoryEntry = 1L,
	eventidReturnError = 2L,
	eventidRioStatus = 3L,
	eventidTransferProgress = 4L,
	//}}AFX_DISP_ID
	};
private:
	BOOL UpdateDirectory();
	BOOL bUseExternal;
	
	long lTimeIODelayRx;
	long lTimeIODelayTx;
	long lTimeIODelayInit;
	int iSizeDumpDirectory;
	int iPosDumpDirectory;
	int iPortBase;
	int intFileCount;
	long lngMemTotal;
	long lngMemFree;
	long lngMemUsed;
	long lngBadBlocks;
	BOOL bInitMarkBadBlock;
	BOOL bInit;
	BOOL bDisplayDir;
	BOOL bUseExternalFlash;
	BOOL bDeleteAll;
	BOOL bVerbose;
	
	
	// set/unset
	void Unset( void );
	BOOL Set( int iPortBase );


	// retrieval
	long GetIODelayInit( void ) { return m_lTimeIODelayInit; }
	long GetIODelayTx( void ) { return m_lTimeIODelayTx; }
	long GetIODelayRx( void ) { return m_lTimeIODelayRx; }
	CDirBlock& GetDirectoryBlock( void ) { return m_cDirBlock; }
	int GetErrorID( void ) { return m_iIDError; }
	char* GetErrorStr( void ) { return m_szError; }
	BOOL GetUseExternalFlashStatus( void ) { return m_bUseExternalFlash; }
	BOOL GetSpecialEditionStatus( void ) { return m_bSpecialEdition; }

	// operations
	void SetIODelayInit( long lTime ) { m_lTimeIODelayInit = lTime; }
	void SetIODelayTx( long lTime ) { m_lTimeIODelayTx = lTime; }
	void SetIODelayRx( long lTime ) { m_lTimeIODelayRx = lTime; }
	void UseExternalFlash( BOOL bUseExternalFlash );
	BOOL CheckPresent( void );
	CDirEntry* FindFile( char* pszFile );
	BOOL Initialize( BOOL bMarkBadBlock );
	BOOL RemoveFile( char* pszFile );
	BOOL RemoveAllFiles( void );
	BOOL SetFileOrder( UINT* pauiPosOrder, UINT uiCount );
	BOOL TxDirectory( void );
	BOOL RxDirectory( void );
	BOOL TxFile( char* pszPathFile );
	BOOL RxFile( char* pszPathFile );
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RIO2000CTL_H__E735C793_FA52_11D3_BDB1_0008C7F48EFD__INCLUDED)
